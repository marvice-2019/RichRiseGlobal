import { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, Stars } from '@react-three/drei'
import type { Mesh } from 'three'

function ForexOrb() {
  const outer = useRef<Mesh>(null)
  const inner = useRef<Mesh>(null)

  useFrame((_, delta) => {
    if (outer.current) outer.current.rotation.y += delta * 0.12
    if (inner.current) inner.current.rotation.x += delta * 0.08
  })

  return (
    <Float speed={1.8} rotationIntensity={0.5} floatIntensity={0.8}>
      <group>
        <mesh ref={outer}>
          <icosahedronGeometry args={[2.2, 2]} />
          <meshStandardMaterial
            color="#2f8df5"
            wireframe
            emissive="#1746c8"
            emissiveIntensity={0.35}
            transparent
            opacity={0.85}
          />
        </mesh>
        <mesh ref={inner}>
          <torusGeometry args={[1.4, 0.04, 16, 80]} />
          <meshStandardMaterial color="#8fd0ff" emissive="#2f8df5" emissiveIntensity={0.6} />
        </mesh>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[1.8, 0.02, 12, 64]} />
          <meshStandardMaterial color="#6366f1" emissive="#4f46e5" emissiveIntensity={0.4} transparent opacity={0.7} />
        </mesh>
      </group>
    </Float>
  )
}

export default function ForexScene3D() {
  return (
    <div className="absolute inset-0 pointer-events-none opacity-50 lg:opacity-70">
      <Canvas camera={{ position: [0, 0, 6], fov: 45 }} gl={{ alpha: true, antialias: true }}>
        <ambientLight intensity={0.4} />
        <pointLight position={[8, 8, 8]} intensity={1.2} color="#2f8df5" />
        <pointLight position={[-6, -4, 4]} intensity={0.6} color="#6366f1" />
        <ForexOrb />
        <Stars radius={40} depth={30} count={1200} factor={3} saturation={0} fade speed={0.8} />
      </Canvas>
    </div>
  )
}
