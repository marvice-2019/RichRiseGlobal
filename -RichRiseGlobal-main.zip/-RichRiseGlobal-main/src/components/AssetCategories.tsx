import { Link } from 'react-router-dom'
import type { ReactNode } from 'react'
import { AnimatedSection, StaggerItem } from './AnimatedSection'
import SectionHeader from './SectionHeader'
import TiltCard from './TiltCard'
import { portfoliosContent } from '../data/siteContent'

const assetIcons: Record<string, ReactNode> = {
  Forex: (
    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
    </svg>
  ),
  Metals: (
    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
  ),
  Indices: (
    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
  ),
  Stocks: (
    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
    </svg>
  ),
  Futures: (
    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
    </svg>
  ),
  Crypto: (
    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
    </svg>
  ),
}

export default function AssetCategories() {
  return (
    <AnimatedSection id="portfolios" className="py-20 lg:py-28 bg-brand-card/20 relative mesh-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          sectionId="portfolios"
          title={portfoliosContent.title}
          titleAccent={portfoliosContent.titleAccent}
          description={portfoliosContent.description}
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {portfoliosContent.assets.map((asset, i) => (
            <StaggerItem key={asset.name} index={i}>
              <TiltCard
                className={`group relative overflow-hidden rounded-2xl border ${
                  asset.featured ? 'border-brand-gold/40 ring-1 ring-brand-gold/20' : 'border-brand-border'
                } bg-gradient-to-br ${asset.color} p-6 flex items-center gap-5`}
              >
                <Link to="/accounts" className="flex items-center gap-5 w-full">
                  <div className="w-14 h-14 rounded-xl bg-[#050b1d]/70 flex items-center justify-center text-brand-gold shrink-0 group-hover:rotate-12 transition-transform">
                    {assetIcons[asset.name]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-semibold">{asset.name}</h3>
                      {asset.featured && (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-brand-gold/20 text-brand-gold uppercase tracking-wider">
                          Core
                        </span>
                      )}
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-brand-gold/15 text-brand-gold">
                        {asset.count}
                      </span>
                    </div>
                    <p className="text-brand-muted text-sm">{asset.description}</p>
                  </div>
                </Link>
              </TiltCard>
            </StaggerItem>
          ))}
        </div>
      </div>
    </AnimatedSection>
  )
}
