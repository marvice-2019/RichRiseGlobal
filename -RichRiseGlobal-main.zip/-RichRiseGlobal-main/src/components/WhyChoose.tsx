import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { AnimatedSection, FadeIn } from './AnimatedSection'
import SectionHeader from './SectionHeader'
import { riseEdgeContent } from '../data/siteContent'

const pillarAccents = [
  { ring: 'from-emerald-500/30 to-emerald-600/5', dot: 'bg-emerald-400', line: 'border-emerald-500/40', glow: 'shadow-emerald-500/10' },
  { ring: 'from-amber-500/30 to-amber-600/5', dot: 'bg-amber-400', line: 'border-amber-500/40', glow: 'shadow-amber-500/10' },
  { ring: 'from-sky-500/30 to-sky-600/5', dot: 'bg-sky-400', line: 'border-sky-500/40', glow: 'shadow-sky-500/10' },
  { ring: 'from-violet-500/30 to-violet-600/5', dot: 'bg-violet-400', line: 'border-violet-500/40', glow: 'shadow-violet-500/10' },
  { ring: 'from-rose-500/30 to-rose-600/5', dot: 'bg-rose-400', line: 'border-rose-500/40', glow: 'shadow-rose-500/10' },
]

const pillarIcons = [
  <svg key="0" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>,
  <svg key="1" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>,
  <svg key="2" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
  </svg>,
  <svg key="3" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
  </svg>,
  <svg key="4" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
  </svg>,
]

export default function WhyChoose() {
  const [active, setActive] = useState(0)
  const featured = riseEdgeContent.pillars[active]
  const accent = pillarAccents[active]

  return (
    <AnimatedSection id="rise-edge" className="py-20 lg:py-28 relative overflow-hidden">
      <div className="absolute inset-0 rise-edge-bg pointer-events-none" />
      <div className="absolute top-0 right-0 w-[480px] h-[480px] rounded-full bg-brand-gold/5 blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-[1fr_1.15fr] gap-12 lg:gap-16 items-start">
          {/* Left — sticky headline + spotlight panel */}
          <div className="lg:sticky lg:top-28">
            <SectionHeader
              sectionId="rise-edge"
              title={riseEdgeContent.title}
              titleAccent={riseEdgeContent.titleAccent}
              description={riseEdgeContent.description}
              align="left"
            />

            <FadeIn delay={0.15}>
              <div className="relative rounded-2xl border border-brand-border/60 bg-brand-card/80 backdrop-blur-sm overflow-hidden glow-border">
                <div className={`absolute inset-0 bg-gradient-to-br ${accent.ring} opacity-60 transition-all duration-500`} />
                <div className="relative p-6 sm:p-8 min-h-[220px] flex flex-col justify-between">
                  <div className="flex items-start justify-between gap-4 mb-6">
                    <motion.div
                      key={active}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 22 }}
                      className={`w-14 h-14 rounded-2xl border ${accent.line} bg-[#050b1d]/70 flex items-center justify-center text-brand-gold`}
                    >
                      {pillarIcons[active]}
                    </motion.div>
                    <span className="text-5xl font-black text-white/5 font-mono leading-none">
                      {String(active + 1).padStart(2, '0')}
                    </span>
                  </div>

                  <AnimatePresence mode="wait">
                    <motion.div
                      key={featured.title}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.25 }}
                    >
                      <span className="inline-block text-[10px] font-bold uppercase tracking-widest text-brand-gold mb-3 px-2.5 py-1 rounded-full bg-brand-gold/10 border border-brand-gold/25">
                        {featured.tag}
                      </span>
                      <h3 className="text-xl sm:text-2xl font-bold mb-3 leading-snug">{featured.title}</h3>
                      <p className="text-brand-muted text-sm sm:text-base leading-relaxed">{featured.description}</p>
                    </motion.div>
                  </AnimatePresence>

                  <div className="flex gap-1.5 mt-8">
                    {riseEdgeContent.pillars.map((_, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setActive(i)}
                        className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                          i === active ? 'bg-brand-gold' : 'bg-brand-border hover:bg-brand-gold/40'
                        }`}
                        aria-label={`Show advantage ${i + 1}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </FadeIn>
          </div>

          {/* Right — vertical timeline list */}
          <div className="relative">
            <div className="absolute left-[19px] top-4 bottom-4 w-px bg-gradient-to-b from-brand-gold/50 via-brand-border to-transparent hidden sm:block" />

            <div className="space-y-3">
              {riseEdgeContent.pillars.map((pillar, i) => {
                const isActive = active === i
                const itemAccent = pillarAccents[i]

                return (
                  <motion.button
                    key={pillar.title}
                    type="button"
                    onClick={() => setActive(i)}
                    className={`w-full text-left group relative pl-0 sm:pl-12 transition-all duration-300 ${
                      isActive ? 'scale-[1.02]' : 'scale-100 opacity-70 hover:opacity-100'
                    }`}
                    initial={{ opacity: 0, x: 24 }}
                    whileInView={{ opacity: isActive ? 1 : 0.7, x: 0 }}
                    viewport={{ once: true, margin: '-40px' }}
                    transition={{ delay: i * 0.08 }}
                  >
                    <span
                      className={`absolute left-0 top-1/2 -translate-y-1/2 hidden sm:flex w-10 h-10 rounded-full border-2 items-center justify-center transition-all duration-300 ${
                        isActive
                          ? `${itemAccent.line} bg-[#050b1d] shadow-lg ${itemAccent.glow}`
                          : 'border-brand-border bg-brand-card'
                      }`}
                    >
                      <span className={`w-2.5 h-2.5 rounded-full transition-colors ${isActive ? itemAccent.dot : 'bg-brand-muted/40'}`} />
                    </span>

                    <div
                      className={`rounded-xl border p-4 sm:p-5 transition-all duration-300 ${
                        isActive
                          ? `bg-gradient-to-r ${itemAccent.ring} border-brand-gold/30 shadow-xl ${itemAccent.glow}`
                          : 'bg-brand-card/40 border-brand-border/50 hover:border-brand-gold/20'
                      }`}
                    >
                      <div className="flex items-center gap-3 sm:gap-4">
                        <div
                          className={`sm:hidden w-10 h-10 rounded-xl shrink-0 flex items-center justify-center border ${
                            isActive ? `${itemAccent.line} text-brand-gold` : 'border-brand-border text-brand-muted'
                          }`}
                        >
                          {pillarIcons[i]}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-mono text-brand-gold/70">{String(i + 1).padStart(2, '0')}</span>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-brand-gold">{pillar.tag}</span>
                          </div>
                          <h4 className={`font-semibold text-sm sm:text-base ${isActive ? 'text-white' : 'text-gray-300'}`}>
                            {pillar.title}
                          </h4>
                        </div>
                        <motion.span
                          className={`hidden sm:block text-brand-gold transition-transform ${isActive ? 'rotate-90' : ''}`}
                          animate={{ x: isActive ? 4 : 0 }}
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                          </svg>
                        </motion.span>
                      </div>
                      {isActive && (
                        <motion.p
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="text-brand-muted text-sm mt-3 pl-0 sm:pl-0 leading-relaxed sm:hidden"
                        >
                          {pillar.description}
                        </motion.p>
                      )}
                    </div>
                  </motion.button>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </AnimatedSection>
  )
}
