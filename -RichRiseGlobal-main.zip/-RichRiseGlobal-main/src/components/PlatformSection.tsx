import { motion } from 'framer-motion'
import { AnimatedSection, FadeIn } from './AnimatedSection'
import SectionHeader from './SectionHeader'
import { riseTerminalContent } from '../data/siteContent'

const featureIcons = [
  <svg key="0" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
  </svg>,
  <svg key="1" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
  </svg>,
  <svg key="2" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
  </svg>,
  <svg key="3" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>,
]

export default function PlatformSection() {
  return (
    <AnimatedSection id="rise-terminal" className="py-20 lg:py-28 bg-brand-card/20 relative mesh-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          sectionId="rise-terminal"
          title={riseTerminalContent.title}
          titleAccent={riseTerminalContent.titleAccent}
          description={riseTerminalContent.description}
        />

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <FadeIn direction="left">
            <div className="space-y-3">
              {riseTerminalContent.features.map((feature, i) => (
                <motion.div
                  key={feature.title}
                  className="flex items-start gap-4 p-4 rounded-xl border border-brand-border/50 bg-[#050b1d]/50 hover:border-brand-gold/30 transition-colors group"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ x: 4 }}
                >
                  <div className="w-10 h-10 rounded-lg bg-brand-gold/10 text-brand-gold flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                    {featureIcons[i]}
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm mb-0.5">{feature.title}</h3>
                    <p className="text-brand-muted text-sm">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </FadeIn>

          <FadeIn direction="right" delay={0.2}>
            <motion.div className="relative" style={{ perspective: 1200 }}>
              <motion.div
                className="rounded-2xl border border-brand-border bg-brand-card overflow-hidden shadow-2xl float-medium"
                style={{ transformStyle: 'preserve-3d' }}
                whileHover={{ rotateY: -8, rotateX: 4, scale: 1.02 }}
                transition={{ type: 'spring', stiffness: 150 }}
              >
                <div className="flex items-center gap-2 px-4 py-3 border-b border-brand-border bg-[#050b1d]">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="ml-3 text-xs text-brand-muted font-medium">{riseTerminalContent.terminalName}</span>
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-lg font-bold">{riseTerminalContent.chartPair}</span>
                      <span className="ml-2 text-xs text-brand-muted">{riseTerminalContent.chartTimeframe}</span>
                    </div>
                    <motion.span
                      className="text-emerald-400 font-mono text-sm font-medium"
                      animate={{ opacity: [1, 0.6, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      {riseTerminalContent.chartPrice}
                    </motion.span>
                  </div>
                  <div className="h-52 rounded-xl bg-[#050b1d] border border-brand-border/30 mb-4 relative overflow-hidden">
                    <svg className="absolute inset-0 w-full h-full p-3" viewBox="0 0 400 160" preserveAspectRatio="none">
                      <motion.polyline
                        fill="none"
                        stroke="#2f8df5"
                        strokeWidth="1.5"
                        points="0,130 30,125 60,110 90,115 120,95 150,100 180,75 210,80 240,55 270,60 300,40 330,45 360,25 400,20"
                        initial={{ pathLength: 0 }}
                        whileInView={{ pathLength: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 2 }}
                      />
                      <polyline
                        fill="url(#terminalGrad)"
                        stroke="none"
                        points="0,130 30,125 60,110 90,115 120,95 150,100 180,75 210,80 240,55 270,60 300,40 330,45 360,25 400,20 400,160 0,160"
                      />
                      <defs>
                        <linearGradient id="terminalGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#2f8df5" stopOpacity="0.25" />
                          <stop offset="100%" stopColor="#2f8df5" stopOpacity="0" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {['BUY', 'SELL', 'ALERT'].map((label) => (
                      <button
                        key={label}
                        type="button"
                        className={`py-2.5 rounded-lg text-xs font-bold border ${
                          label === 'BUY' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                          label === 'SELL' ? 'bg-rose-500/20 text-rose-400 border-rose-500/30' :
                          'bg-brand-gold/20 text-brand-gold border-brand-gold/30'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="absolute -top-5 -left-5 w-16 h-16 rounded-full border-2 border-dashed border-brand-gold/20 spin-slow"
                aria-hidden
              />
            </motion.div>
          </FadeIn>
        </div>
      </div>
    </AnimatedSection>
  )
}
