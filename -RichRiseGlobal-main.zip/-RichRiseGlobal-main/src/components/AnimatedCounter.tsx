import { useEffect, useState } from 'react'
import { motion, useSpring, useTransform } from 'framer-motion'

interface AnimatedCounterProps {
  value: string
  className?: string
}

export default function AnimatedCounter({ value, className = '' }: AnimatedCounterProps) {
  const numeric = parseFloat(value.replace(/[^0-9.]/g, ''))
  const prefix = value.match(/^[^\d]*/)?.[0] ?? ''
  const suffix = value.match(/[^\d.]*$/)?.[0] ?? ''
  const hasDecimal = value.includes('.')

  const spring = useSpring(0, { stiffness: 60, damping: 20 })
  const display = useTransform(spring, (v) => {
    if (Number.isNaN(numeric)) return value
    if (hasDecimal) return `${prefix}${v.toFixed(1)}${suffix}`
    if (value.includes('K')) return `${prefix}${Math.round(v)}K${suffix.replace('K', '')}`
    return `${prefix}${Math.round(v)}${suffix}`
  })

  const [text, setText] = useState(value)

  useEffect(() => {
    if (!Number.isNaN(numeric)) spring.set(numeric)
  }, [numeric, spring])

  useEffect(() => {
    const unsub = display.on('change', setText)
    return unsub
  }, [display])

  return (
    <motion.span className={className} key={text}>
      {Number.isNaN(numeric) ? value : text}
    </motion.span>
  )
}
