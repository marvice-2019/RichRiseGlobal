import { FadeIn } from './AnimatedSection'

interface PageHeroProps {
  label: string
  title: string
  titleAccent?: string
  description: string
}

export default function PageHero({ label, title, titleAccent, description }: PageHeroProps) {
  return (
    <section className="pt-28 pb-12 lg:pt-36 lg:pb-16 relative overflow-hidden">
      <div className="absolute inset-0 hero-glow mesh-gradient pointer-events-none" />
      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <FadeIn>
          <span className="inline-block text-brand-gold text-xs font-bold uppercase tracking-[0.25em] mb-4">
            {label}
          </span>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold mb-5 leading-tight">
            {title}{' '}
            {titleAccent && <span className="gradient-text">{titleAccent}</span>}
          </h1>
          <p className="text-brand-muted text-lg leading-relaxed max-w-2xl mx-auto">{description}</p>
        </FadeIn>
      </div>
    </section>
  )
}
