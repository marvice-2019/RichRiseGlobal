import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { primaryNav, secondaryNav, authLinks } from '../data/siteContent'

const allNav = [...primaryNav, ...secondaryNav]

function NavItem({ to, label, onClick }: { to: string; label: string; onClick?: () => void }) {
  return (
    <NavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) =>
        `relative px-2 xl:px-2.5 py-1.5 text-[10px] xl:text-[11px] font-semibold uppercase tracking-wide whitespace-nowrap transition-colors rounded-lg ${
          isActive
            ? 'text-brand-gold bg-brand-gold/10'
            : 'text-brand-muted hover:text-white hover:bg-white/5'
        }`
      }
    >
      {({ isActive }) => (
        <>
          {label}
          {isActive && (
            <motion.span
              layoutId="nav-pill"
              className="absolute inset-0 rounded-lg border border-brand-gold/30 -z-10"
              transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            />
          )}
        </>
      )}
    </NavLink>
  )
}

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 left-0 right-0 z-50"
    >
      <div className="mx-3 sm:mx-4 lg:mx-6 mt-3">
        <div className="nav-shell max-w-7xl mx-auto rounded-2xl border border-brand-border/50 bg-[#050b1d]/80 backdrop-blur-xl shadow-lg shadow-black/20">
          <div className="flex items-center justify-between gap-3 h-20 px-3 sm:px-5 lg:px-6">
            <Link
              to="/"
              className="shrink-0 rounded-xl"
              aria-label="Richrise Global home"
            >
              <img
                src="/richrise-logo.png"
                alt="Richrise Global — Trade Smart, Grow Rich"
                className="w-36 xl:w-44 h-auto mix-blend-screen"
              />
            </Link>

            <nav className="hidden lg:flex items-center justify-center gap-0.5 flex-1 min-w-0 overflow-x-auto">
              {allNav.map((item) => (
                <NavItem key={item.id} to={item.path} label={item.label} />
              ))}
            </nav>

            <div className="hidden lg:flex items-center gap-2 shrink-0">
              <Link
                to={authLinks.login.path}
                className="px-3 py-2 text-[10px] xl:text-xs font-semibold uppercase tracking-wider text-brand-muted hover:text-white transition-colors whitespace-nowrap"
              >
                {authLinks.login.label}
              </Link>
              <Link
                to={authLinks.register.path}
                className="btn-primary px-4 py-2 rounded-lg text-[10px] xl:text-xs font-semibold uppercase tracking-wider whitespace-nowrap"
              >
                {authLinks.register.label}
              </Link>
            </div>

            <button
              type="button"
              className="lg:hidden p-2 text-brand-muted hover:text-white shrink-0"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {menuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mx-3 sm:mx-4 mt-2 rounded-2xl border border-brand-border bg-[#050b1d]/95 backdrop-blur-xl overflow-hidden lg:hidden"
          >
            <nav className="px-4 py-4 flex flex-col gap-1">
              {allNav.map((item) => (
                <NavLink
                  key={item.id}
                  to={item.path}
                  onClick={() => setMenuOpen(false)}
                  className={({ isActive }) =>
                    `px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                      isActive ? 'text-brand-gold bg-brand-gold/10' : 'text-brand-muted hover:text-white hover:bg-white/5'
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-brand-border">
                <Link
                  to={authLinks.login.path}
                  onClick={() => setMenuOpen(false)}
                  className="px-3 py-2.5 text-sm font-medium text-center text-brand-muted"
                >
                  {authLinks.login.label}
                </Link>
                <Link
                  to={authLinks.register.path}
                  onClick={() => setMenuOpen(false)}
                  className="btn-primary px-5 py-2.5 rounded-lg text-sm text-center"
                >
                  {authLinks.register.label}
                </Link>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="h-24" aria-hidden />
    </motion.header>
  )
}
