import { AnimatedSection, StaggerItem } from './AnimatedSection'
import SectionHeader from './SectionHeader'
import TiltCard from './TiltCard'
import { marketsContent } from '../data/siteContent'

const featureIcons = [
  <svg key="0" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>,
  <svg key="1" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>,
  <svg key="2" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>,
  <svg key="3" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
  </svg>,
]

export default function TradingExperience() {
  return (
    <AnimatedSection id="markets" className="py-20 lg:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          sectionId="markets"
          title={marketsContent.title}
          titleAccent={marketsContent.titleAccent}
          description={marketsContent.description}
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {marketsContent.features.map((feature, i) => (
            <StaggerItem key={feature.title} index={i}>
              <TiltCard className="group h-full p-6 rounded-2xl border border-brand-border bg-brand-card cursor-pointer shadow-lg shadow-black/20">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-gold/20 to-brand-gold/5 text-brand-gold flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                  {featureIcons[i]}
                </div>
                <h3 className="text-base font-semibold mb-2 leading-snug">{feature.title}</h3>
                <p className="text-brand-muted text-sm leading-relaxed">{feature.description}</p>
              </TiltCard>
            </StaggerItem>
          ))}
        </div>
      </div>
    </AnimatedSection>
  )
}
