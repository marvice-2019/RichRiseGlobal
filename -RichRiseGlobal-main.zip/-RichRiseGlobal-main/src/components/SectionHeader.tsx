import { motion } from 'framer-motion'
import { FadeIn } from './AnimatedSection'
import { sections } from '../data/siteContent'

interface SectionHeaderProps {
  label?: string
  sectionId?: string
  title: string
  titleAccent?: string
  description: string
  align?: 'center' | 'left'
}

export default function SectionHeader({
  label,
  sectionId,
  title,
  titleAccent,
  description,
  align = 'center',
}: SectionHeaderProps) {
  const meta = sectionId ? sections.find((s) => s.id === sectionId) : undefined
  const displayLabel = label ?? meta?.label ?? ''
  const displayNumber = meta?.number
  const isCenter = align === 'center'

  return (
    <FadeIn>
      <div className={`mb-14 lg:mb-16 ${isCenter ? 'text-center' : 'text-left'}`}>
        <div className={`flex items-center gap-3 mb-5 ${isCenter ? 'justify-center' : ''}`}>
          <motion.span
            className="section-number"
            whileInView={{ scale: [0.8, 1.1, 1], rotate: [0, 5, 0] }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            {displayNumber ?? '00'}
          </motion.span>
          <span className="h-px w-12 bg-gradient-to-r from-brand-gold/60 to-transparent" />
          <span className="text-brand-gold text-xs font-bold uppercase tracking-[0.25em]">
            {displayLabel}
          </span>
        </div>
        <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 ${isCenter ? 'max-w-4xl mx-auto' : 'max-w-3xl'}`}>
          {title}{' '}
          {titleAccent && <span className="gradient-text">{titleAccent}</span>}
        </h2>
        <p className={`text-brand-muted text-lg leading-relaxed ${isCenter ? 'max-w-2xl mx-auto' : 'max-w-xl'}`}>
          {description}
        </p>
      </div>
    </FadeIn>
  )
}
