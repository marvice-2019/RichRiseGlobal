import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { AnimatedSection, FadeIn } from './AnimatedSection'
import SectionHeader from './SectionHeader'
import { intelligenceContent, authLinks } from '../data/siteContent'

export default function MarketIntelligence() {
  return (
    <AnimatedSection id="intelligence" className="py-20 lg:py-28 relative overflow-hidden">
      <div className="absolute inset-0 aurora-bg pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <FadeIn direction="left">
            <SectionHeader
              sectionId="intelligence"
              title={intelligenceContent.title}
              titleAccent={intelligenceContent.titleAccent}
              description={intelligenceContent.description}
              align="left"
            />
            <div className="flex flex-wrap gap-4 -mt-6">
              <Link to={authLinks.register.path} className="btn-primary px-8 py-3.5 rounded-xl text-sm inline-block">
                {intelligenceContent.ctaPrimary}
              </Link>
              <Link to={authLinks.register.path} className="btn-outline px-8 py-3.5 rounded-xl text-sm inline-block">
                {intelligenceContent.ctaSecondary}
              </Link>
            </div>
          </FadeIn>

          <FadeIn direction="right" delay={0.2}>
            <motion.div
              className="glass-panel rounded-2xl p-8 float-slow"
              style={{ transformStyle: 'preserve-3d' }}
              whileHover={{ rotateY: 8, rotateX: -4 }}
            >
              <div className="flex items-center justify-between mb-6">
                <span className="text-sm font-semibold">{intelligenceContent.feedTitle}</span>
                <motion.span
                  className="text-xs px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 font-medium"
                  animate={{ opacity: [1, 0.5, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  {intelligenceContent.feedStatus}
                </motion.span>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                {intelligenceContent.signals.map((signal, i) => (
                  <motion.div
                    key={signal.label}
                    className="p-4 rounded-xl bg-[#050b1d]/80 border border-brand-border/40"
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <div className="text-xs text-brand-muted mb-2">{signal.label}</div>
                    <div className={`text-2xl font-bold mb-2 ${signal.accent}`}>{signal.value}%</div>
                    <div className="h-1.5 rounded-full bg-brand-border overflow-hidden">
                      <motion.div
                        className={`h-full rounded-full ${signal.color}`}
                        initial={{ width: 0 }}
                        whileInView={{ width: `${signal.value}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.3 + i * 0.1 }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="space-y-3">
                {intelligenceContent.insights.map((item, i) => (
                  <motion.div
                    key={item.time}
                    className="flex items-start gap-3 p-3 rounded-lg bg-[#050b1d]/60 border border-brand-border/30"
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.5 + i * 0.15 }}
                  >
                    <span className={`mt-1 w-2 h-2 rounded-full shrink-0 ${
                      item.type === 'signal' ? 'bg-emerald-400' :
                      item.type === 'alert' ? 'bg-brand-gold' : 'bg-indigo-400'
                    }`} />
                    <div>
                      <span className="text-[10px] text-brand-muted font-mono">{item.time}</span>
                      <p className="text-sm text-gray-300">{item.event}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </FadeIn>
        </div>
      </div>
    </AnimatedSection>
  )
}
