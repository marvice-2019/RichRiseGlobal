import { motion } from 'framer-motion'

const candles = [
  { x: 8, bullish: true, h: 28, w: 6 },
  { x: 22, bullish: false, h: 18, w: 6 },
  { x: 36, bullish: true, h: 35, w: 6 },
  { x: 50, bullish: true, h: 22, w: 6 },
  { x: 64, bullish: false, h: 15, w: 6 },
  { x: 78, bullish: true, h: 40, w: 6 },
  { x: 92, bullish: true, h: 30, w: 6 },
]

export default function CandlestickChart({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 50" preserveAspectRatio="none">
      <defs>
        <linearGradient id="candleGradUp" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#34d399" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#34d399" stopOpacity="0.1" />
        </linearGradient>
        <linearGradient id="candleGradDown" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f87171" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#f87171" stopOpacity="0.1" />
        </linearGradient>
      </defs>
      {candles.map((c, i) => (
        <motion.g
          key={i}
          initial={{ opacity: 0, scaleY: 0 }}
          animate={{ opacity: 1, scaleY: 1 }}
          transition={{ delay: 0.8 + i * 0.08, duration: 0.4 }}
          style={{ transformOrigin: `${c.x}px 50px` }}
        >
          <line
            x1={c.x + c.w / 2}
            y1={50 - c.h - 5}
            x2={c.x + c.w / 2}
            y2={50}
            stroke={c.bullish ? '#34d399' : '#f87171'}
            strokeWidth="0.5"
            opacity="0.6"
          />
          <rect
            x={c.x}
            y={50 - c.h}
            width={c.w}
            height={c.h}
            rx="1"
            fill={c.bullish ? 'url(#candleGradUp)' : 'url(#candleGradDown)'}
          />
        </motion.g>
      ))}
      <motion.polyline
        fill="none"
        stroke="#2f8df5"
        strokeWidth="0.8"
        strokeDasharray="2 1"
        opacity="0.5"
        points="5,42 20,38 35,30 50,32 65,25 80,18 95,12"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 2, delay: 1.2 }}
      />
    </svg>
  )
}
