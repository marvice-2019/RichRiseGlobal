import { lazy, Suspense } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FadeIn } from './AnimatedSection'
import AnimatedCounter from './AnimatedCounter'
import CandlestickChart from './CandlestickChart'
import TradingGrid from './TradingGrid'
import { heroContent, ctaButtons, authLinks } from '../data/siteContent'

const ForexScene3D = lazy(() => import('./ForexScene3D'))

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex flex-col overflow-hidden">
      <div className="absolute inset-0 hero-glow mesh-gradient" />
      <Suspense fallback={null}>
        <ForexScene3D />
      </Suspense>
      <TradingGrid />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-28 w-full flex-1 flex items-center">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center w-full">
          <div>
            <FadeIn>
              <motion.div
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-brand-gold/30 bg-brand-gold/5 mb-6 shimmer-border"
                animate={{ boxShadow: ['0 0 0px rgba(47,141,245,0)', '0 0 24px rgba(47,141,245,0.25)', '0 0 0px rgba(47,141,245,0)'] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-semibold text-brand-gold tracking-wider uppercase">
                  {heroContent.badge}
                </span>
              </motion.div>
            </FadeIn>

            <FadeIn delay={0.1}>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-[1.1] mb-6">
                <motion.span
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  {heroContent.headlineLine1}{' '}
                </motion.span>
                <motion.span
                  className="gradient-text inline-block"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.35 }}
                >
                  {heroContent.headlineAccent}
                </motion.span>
              </h1>
            </FadeIn>

            <FadeIn delay={0.2}>
              <p className="text-brand-muted text-lg leading-relaxed mb-8 max-w-xl">
                {heroContent.description}
              </p>
            </FadeIn>

            <FadeIn delay={0.3}>
              <div className="flex flex-wrap gap-4 mb-10">
                <motion.div whileHover={{ scale: 1.05, boxShadow: '0 12px 32px rgba(47,141,245,0.35)' }} whileTap={{ scale: 0.95 }}>
                  <Link to={authLinks.register.path} className="btn-primary px-8 py-3.5 rounded-xl text-sm inline-block">
                    {ctaButtons.practice}
                  </Link>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Link to={authLinks.register.path} className="btn-outline px-8 py-3.5 rounded-xl text-sm inline-block">
                    {ctaButtons.live}
                  </Link>
                </motion.div>
              </div>
            </FadeIn>

            <FadeIn delay={0.4}>
              <div className="flex flex-wrap gap-8">
                {heroContent.stats.map((stat, i) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 + i * 0.1 }}
                  >
                    <div className="text-2xl font-bold gradient-text">
                      <AnimatedCounter value={stat.value} />
                    </div>
                    <div className="text-xs text-brand-muted uppercase tracking-wider mt-1">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </FadeIn>
          </div>

          <FadeIn delay={0.2} direction="right">
            <div className="relative" style={{ perspective: 1200 }}>
              <motion.div
                className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-brand-gold/10 via-transparent to-indigo-500/10 blur-2xl"
                animate={{ opacity: [0.4, 0.7, 0.4], scale: [0.98, 1.02, 0.98] }}
                transition={{ duration: 5, repeat: Infinity }}
              />

              <motion.div
                className="glass-panel rounded-2xl p-6 shadow-2xl float-slow relative z-10 glow-border"
                style={{ transformStyle: 'preserve-3d' }}
                whileHover={{ rotateY: -6, rotateX: 4, scale: 1.02 }}
                transition={{ type: 'spring', stiffness: 200 }}
              >
                <div className="flex items-center justify-between mb-5">
                  <span className="text-sm font-medium text-brand-muted">{heroContent.dashboardTitle}</span>
                  <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                    <motion.span
                      className="w-2 h-2 rounded-full bg-emerald-400"
                      animate={{ scale: [1, 1.4, 1], opacity: [1, 0.5, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    />
                    {heroContent.dashboardStatus}
                  </span>
                </div>

                <div className="space-y-2.5">
                  {heroContent.liveStats.map((item, i) => (
                    <motion.div
                      key={item.pair}
                      className="flex items-center justify-between p-3 rounded-xl bg-[#050b1d]/80 border border-brand-border/40 hover:border-brand-gold/30 transition-colors"
                      initial={{ opacity: 0, x: 30 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + i * 0.12 }}
                      whileHover={{ x: 4, backgroundColor: 'rgba(47,141,245,0.05)' }}
                    >
                      <span className="font-semibold text-sm">{item.pair}</span>
                      <div className="text-right">
                        <motion.span
                          className="block text-sm font-mono"
                          animate={{ opacity: [1, 0.7, 1] }}
                          transition={{ duration: 2 + i * 0.3, repeat: Infinity }}
                        >
                          {item.price}
                        </motion.span>
                        <span className={`text-xs font-medium ${item.up ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {item.change}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-5 h-28 rounded-xl bg-[#050b1d]/60 border border-brand-border/30 overflow-hidden relative">
                  <CandlestickChart className="w-full h-full p-2" />
                </div>
              </motion.div>

              <motion.div
                className="absolute -top-5 -right-5 px-3 py-1.5 rounded-lg glass-panel text-xs font-semibold text-emerald-400 z-20 float-fast"
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                {heroContent.floatBadgeTop}
              </motion.div>

              <motion.div
                className="absolute -bottom-4 -left-4 px-3 py-1.5 rounded-lg glass-panel text-xs font-semibold text-brand-gold z-20 float-medium"
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 4, repeat: Infinity, delay: 1 }}
              >
                {heroContent.floatBadgeBottom}
              </motion.div>
            </div>
          </FadeIn>
        </div>
      </div>

      <div className="relative border-y border-brand-border/40 bg-brand-card/30 overflow-hidden py-3 backdrop-blur-sm">
        <div className="flex ticker-scroll whitespace-nowrap">
          {[...heroContent.ticker, ...heroContent.ticker].map((item, i) => (
            <span key={i} className="inline-flex items-center mx-8 text-sm text-brand-muted">
              <motion.span
                className="w-1.5 h-1.5 rounded-full bg-brand-gold mr-3"
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: i * 0.2 }}
              />
              {item}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
