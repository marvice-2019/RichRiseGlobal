import { motion } from 'framer-motion'

const orbs = [
  { size: 320, top: '8%', left: '5%', delay: 0, color: 'rgba(47,141,245,0.12)' },
  { size: 200, top: '55%', left: '75%', delay: 1.5, color: 'rgba(99,102,241,0.08)' },
  { size: 160, top: '70%', left: '15%', delay: 0.8, color: 'rgba(47,141,245,0.06)' },
  { size: 100, top: '20%', left: '80%', delay: 2, color: 'rgba(16,185,129,0.06)' },
]

const shapes = [
  { top: '15%', right: '12%', size: 80, rotate: 45 },
  { bottom: '25%', left: '8%', size: 60, rotate: 12 },
  { top: '45%', right: '25%', size: 40, rotate: -20 },
]

export default function FloatingBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden>
      {orbs.map((orb, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full blur-3xl"
          style={{
            width: orb.size,
            height: orb.size,
            top: orb.top,
            left: orb.left,
            background: orb.color,
          }}
          animate={{
            y: [0, -30, 0, 20, 0],
            x: [0, 15, -10, 5, 0],
            scale: [1, 1.1, 0.95, 1.05, 1],
          }}
          transition={{
            duration: 12 + i * 2,
            repeat: Infinity,
            delay: orb.delay,
            ease: 'easeInOut',
          }}
        />
      ))}

      {shapes.map((shape, i) => (
        <motion.div
          key={`shape-${i}`}
          className="absolute border border-brand-gold/10 rounded-xl"
          style={{
            width: shape.size,
            height: shape.size,
            top: shape.top,
            bottom: shape.bottom,
            left: shape.left,
            right: shape.right,
            transformStyle: 'preserve-3d',
          }}
          animate={{
            rotateX: [0, 15, -10, 0],
            rotateY: [shape.rotate, shape.rotate + 20, shape.rotate - 10, shape.rotate],
            y: [0, -25, 10, 0],
          }}
          transition={{
            duration: 10 + i * 3,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      ))}

      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,#050b1d_75%)]" />
    </div>
  )
}
