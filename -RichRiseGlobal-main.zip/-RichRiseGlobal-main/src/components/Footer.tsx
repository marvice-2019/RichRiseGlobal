import { Link } from 'react-router-dom'
import { company, legalCopy, footerLinks, footerCopy, contactContent } from '../data/siteContent'

// function SocialIcon({ name }: { name: string }) {
//   if (name === 'Instagram') {
//     return (
//       <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden>
//         <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
//       </svg>
//     )
//   }
//   if (name === 'Telegram') {
//     return (
//       <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden>
//         <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
//       </svg>
//     )
//   }
//   return (
//     <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden>
//       <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
//     </svg>
//   )
// }

export default function Footer() {
  return (
    <footer id="contact" className="border-t border-brand-border bg-[#030714] relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div className="lg:col-span-1">
            <Link
              to="/"
              className="inline-block mb-5"
              aria-label="Richrise Global home"
            >
              <img
                src="/richrise-logo.png"
                alt="Richrise Global — Trade Smart, Grow Rich"
                className="w-52 h-auto mix-blend-screen"
              />
            </Link>
            <p className="text-brand-muted text-sm mb-1">{company.website}</p>
            <p className="text-brand-muted text-xs">{company.legalName}</p>
            <p className="text-brand-muted text-xs mb-4">
              Company Registration No. {company.registrationNumber}
            </p>

            <div className="space-y-3 mb-5">
              <a
                href={company.emailHref}
                className="flex items-center gap-2 text-brand-muted text-sm hover:text-brand-gold transition-colors"
              >
                <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                {company.email}
              </a>
              <a
                href={company.phoneHref}
                className="flex items-center gap-2 text-brand-gold text-sm font-semibold hover:underline"
              >
                <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                {company.phone}
              </a>
            </div>

            
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-4">{footerCopy.navigateHeading}</h4>
            <ul className="space-y-2">
              {footerLinks.map((link) => (
                <li key={link.label}>
                  <Link to={link.href} className="text-brand-muted text-sm hover:text-brand-gold-light transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-4">{footerCopy.contactHeading}</h4>
            <p className="text-brand-muted text-sm leading-relaxed mb-3">{contactContent.description}</p>
            <p className="text-brand-muted text-xs">{contactContent.hours}</p>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-4">{footerCopy.registeredHeading}</h4>
            <p className="text-brand-muted text-sm leading-relaxed">{company.registeredOffice}</p>
            <h4 className="text-sm font-semibold uppercase tracking-wider mt-6 mb-4">Physical Address</h4>
            <p className="text-brand-muted text-sm leading-relaxed">{company.physicalOffice}</p>
          </div>

          {/* <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-4">Client Support</h4>
            <p className="text-brand-muted text-sm leading-relaxed">{footerCopy.supportNote}</p>
          </div> */}
        </div>

        <div className="section-divider mb-8" />

        <div className="space-y-4 text-brand-muted text-xs leading-relaxed">
          <p>{legalCopy.about}</p>
          <p>
            <strong className="text-gray-400">Risk Warning:</strong> {legalCopy.riskWarning}
          </p>
          <p>
            <strong className="text-gray-400">Restricted Regions:</strong> {legalCopy.restrictedRegions}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-10 pt-8 border-t border-brand-border">
          <p className="text-brand-muted text-xs">
            &copy; {new Date().getFullYear()} {company.tradingName}. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/support" className="text-brand-muted text-xs hover:text-brand-gold-light transition-colors">
              {footerCopy.termsLabel}
            </Link>
            <Link to="/support" className="text-brand-muted text-xs hover:text-brand-gold-light transition-colors">
              {footerCopy.privacyLabel}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
