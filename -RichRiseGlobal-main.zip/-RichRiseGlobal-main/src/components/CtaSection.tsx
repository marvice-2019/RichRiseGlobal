import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { AnimatedSection, FadeIn } from './AnimatedSection'
import AnimatedCounter from './AnimatedCounter'
import { ctaContent, ctaButtons, authLinks } from '../data/siteContent'

export default function CtaSection() {
  return (
    <AnimatedSection id="begin" className="py-20 lg:py-28 relative overflow-hidden">
      <div className="absolute inset-0 aurora-bg pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] rounded-full bg-brand-gold/8 blur-3xl pointer-events-none" />
      <div className="absolute inset-0 cta-grid-bg pointer-events-none opacity-40" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeIn>
          <div className="relative rounded-3xl border border-brand-border/60 bg-brand-card/40 backdrop-blur-xl overflow-hidden glow-border">
            <div className="absolute inset-0 bg-gradient-to-br from-brand-gold/10 via-transparent to-indigo-500/10 pointer-events-none" />
            <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full border border-brand-gold/20 spin-slow pointer-events-none" />
            <div className="absolute -bottom-16 -left-16 w-32 h-32 rounded-full border border-indigo-500/20 spin-slow pointer-events-none" style={{ animationDirection: 'reverse' }} />

            <div className="relative px-6 py-12 sm:px-12 sm:py-16 text-center">
              <motion.div
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-brand-gold/30 bg-brand-gold/5 mb-8"
                animate={{ boxShadow: ['0 0 0px rgba(47,141,245,0)', '0 0 28px rgba(47,141,245,0.3)', '0 0 0px rgba(47,141,245,0)'] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-semibold text-brand-gold tracking-wider uppercase">
                  {ctaContent.badge}
                </span>
              </motion.div>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-extrabold mb-10 leading-tight">
                {ctaContent.title}{' '}
                <span className="gradient-text block sm:inline mt-1 sm:mt-0">{ctaContent.titleAccent}</span>
              </h2>

              <div className="flex flex-wrap justify-center gap-6 sm:gap-10 mb-10">
                {ctaContent.highlights.map((item, i) => (
                  <motion.div
                    key={item.label}
                    className="text-center"
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.2 + i * 0.1 }}
                  >
                    <div className="text-2xl sm:text-3xl font-bold gradient-text">
                      <AnimatedCounter value={item.value} />
                    </div>
                    <div className="text-[10px] sm:text-xs text-brand-muted uppercase tracking-wider mt-1">
                      {item.label}
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="flex flex-wrap justify-center gap-4">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }}>
                  <Link to={authLinks.register.path} className="btn-primary px-10 py-4 rounded-xl text-sm font-semibold min-w-[180px] inline-block">
                    {ctaButtons.practice}
                  </Link>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }}>
                  <Link to={authLinks.register.path} className="btn-outline px-10 py-4 rounded-xl text-sm font-semibold min-w-[180px] inline-block">
                    {ctaButtons.live}
                  </Link>
                </motion.div>
              </div>
            </div>

            <div className="relative border-t border-brand-border/40 bg-[#050b1d]/50 overflow-hidden py-2.5">
              <div className="flex cta-ticker whitespace-nowrap">
                {[...Array(2)].map((_, set) => (
                  <span key={set} className="flex shrink-0">
                    {['EUR/USD', 'GBP/USD', 'USD/JPY', 'XAU/USD', 'AUD/USD', 'USD/CAD'].map((pair) => (
                      <span key={`${set}-${pair}`} className="inline-flex items-center mx-6 text-xs text-brand-muted font-mono">
                        <span className="w-1 h-1 rounded-full bg-emerald-400 mr-2" />
                        {pair}
                        <span className="ml-2 text-emerald-400/80">LIVE</span>
                      </span>
                    ))}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </FadeIn>
      </div>
    </AnimatedSection>
  )
}
