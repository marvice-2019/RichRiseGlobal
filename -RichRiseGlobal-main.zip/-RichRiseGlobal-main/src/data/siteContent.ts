export const company = {
  legalName: 'RICHRISE GLOBAL LIMITED',
  registrationNumber: '2026-00527',
  tradingName: 'Rich Rise Global',
  website: 'richriseglobal.ai',
  websiteUrl: 'https://richriseglobal.ai',
  email: 'support@richriseglobal.ai',
  emailHref: 'mailto:support@richriseglobal.ai',
  phone: '+44 20 7097 0811',
  phoneHref: 'tel:+442070970811',
  registeredOffice:
    'Ground Floor, The Sotheby Building, Rodney Village, Rodney Bay, Gros-Islet, Saint Lucia.',
  physicalOffice:
    '33G5+32G Rodney Bay, Bella Rosa Road, Office 14, St. Lucia.',
  supportLanguages: 14,
} as const

export const contactContent = {
  title: 'Get in Touch',
  description: 'Reach our client desk for account help, platform questions, or partnership enquiries.',
  hours: 'Monday – Friday, 24 hours · Weekend desk on request',
} as const

export const socialLinks = [
  { name: 'Instagram', href: '#', label: 'Follow Rich Rise on Instagram' },
  { name: 'Telegram', href: '#', label: 'Join Rich Rise on Telegram' },
  { name: 'LinkedIn', href: '#', label: 'Connect with Rich Rise on LinkedIn' },
] as const

export const restrictedRegions = [
  'United States',
  'Cuba',
  'Iraq',
  'Myanmar',
  'North Korea',
  'Sudan',
  'Russia',
  'Iran',
  'UAE',
] as const

export const legalCopy = {
  about: `${company.legalName} (Company Registration No. ${company.registrationNumber}) operates the ${company.tradingName} brand from Saint Lucia. We provide access to international currency and derivatives markets through trading technology, customer support, and transparent service terms.`,
  riskWarning: `Margined trading in forex, CFDs, and related instruments can lead to significant losses within a short period and is not appropriate for all individuals. Because positions are leveraged, losses may exceed deposited funds. Review all risk documentation carefully and consult an independent adviser before committing capital.`,
  restrictedRegions: `We do not accept applications from persons residing in ${restrictedRegions.join(', ')}, nor from territories where retail CFD or forex services are unavailable under local law. Geographic eligibility is confirmed during the account-opening process.`,
} as const

export const footerCopy = {
  supportNote: `Round-the-clock client care is available in ${company.supportLanguages} languages.`,
  termsLabel: 'Terms of Service',
  privacyLabel: 'Privacy Notice',
  navigateHeading: 'Site Map',
  registeredHeading: 'Registered Office',
  contactHeading: 'Contact',
} as const

export const primaryNav = [
  { id: 'home', label: 'Home', path: '/' },
  { id: 'markets', label: 'Markets', path: '/markets' },
  { id: 'accounts', label: 'Accounts', path: '/accounts' },
  { id: 'partners', label: 'Affiliates', path: '/partners' },
  { id: 'platforms', label: 'Platforms', path: '/platforms' },
] as const

export const secondaryNav = [
  { id: 'resources', label: 'Resources', path: '/resources' },
  { id: 'support', label: 'Help Desk', path: '/support' },
] as const

export const authLinks = {
  login: { label: 'Member Login', path: 'https://portal.richriseglobal.ai/user/login' },
  register: { label: 'Create Account', path: 'https://portal.richriseglobal.ai/user/register' },
} as const

export const footerNav = [...primaryNav.filter((n) => n.id !== 'home'), ...secondaryNav]

/** Home page section anchors (numbered headers on landing page) */
export const sections = [
  { id: 'home', label: 'Home', number: '01', href: '#home' },
  { id: 'markets', label: 'Markets', number: '02', href: '#markets' },
  { id: 'portfolios', label: 'Instruments', number: '03', href: '#portfolios' },
  { id: 'intelligence', label: 'Derivatives', number: '04', href: '#intelligence' },
  { id: 'rise-edge', label: 'Advantages', number: '05', href: '#rise-edge' },
  { id: 'rise-terminal', label: 'Platforms', number: '06', href: '#rise-terminal' },
  { id: 'contact', label: 'Help Desk', number: '07', href: '#contact' },
] as const

export const navLinks = primaryNav.map(({ label, path }) => ({ label, href: path }))
export const footerLinks = footerNav.map(({ label, path }) => ({ label, href: path }))
export const sectionIds = sections.map((s) => s.id)

export const pageContent = {
  markets: {
    label: 'Markets',
    title: 'Access Global',
    titleAccent: 'Trading Opportunities',
    description:
      'Explore deep liquidity, flexible order types, and competitive conditions built for every trading style — from quick scalps to multi-week positions.',
  },
  accounts: {
    label: 'Account Plans',
    title: 'Profiles Built for',
    titleAccent: 'Every Trader',
    description:
      'Choose the account type that fits your trading experience, capital, and strategy. Start small or unlock advanced trading conditions as you grow.',
    tiers: [
      {
        name: 'Starter Account',
        deposit: 'From $100',
        description:
          'For new and entry-level traders looking to start trading with a simple and accessible account structure.',
        perks: [
          'Minimum deposit from $100',
          'Full platform access',
          'Standard trading support',
        ],
      },
      {
        name: 'Classic Account',
        deposit: 'From $500',
        description:
          'Designed for regular and experienced traders seeking a balanced account structure for consistent trading.',
        perks: [
          'Minimum deposit from $500',
          'Competitive trading conditions',
          'Priority trading support',
        ],
      },
      {
        name: 'Prime Account',
        deposit: 'From $2,000',
        description:
          'Built for advanced and premium traders who want access to a higher-tier trading experience.',
        perks: [
          'Minimum deposit from $2,000',
          'Premium trading conditions',
          'Enhanced support',
        ],
        featured: true,
      },
     
    ],
    steps: [
      {
        title: 'Choose your account',
        description:
          'Select the account type that matches your trading experience and capital.',
      },
      {
        title: 'Verify your identity',
        description:
          'Complete a quick KYC verification to activate your trading account.',
      },
      {
        title: 'Fund and trade',
        description:
          'Deposit funds, access the trading platform, and start trading.',
      },
    ],
  },
  partners: {
    label: 'Affiliates',
    title: 'Scale Revenue With',
    titleAccent: 'Rich Rise',
    description:
      'Introduce clients to the Rich Rise multi-asset trading platform and earn competitive commissions on qualified volume.',
    stats: [
      { value: '85K+', label: 'Active Referrals' },
      { value: '$800M', label: 'Monthly Volume' },
      { value: '$2.1M', label: 'Partner Payouts' },
    ],
    programs: [
      {
        title: 'Referral Partner',
        description: 'Refer traders and earn tiered rebates on every qualified lot they execute.',
      },
      {
        title: 'White Label',
        description: 'Launch your own branded front-end while we handle pricing, risk, and technology.',
      },
      {
        title: 'Regional Representative',
        description: 'Represent Rich Rise in your territory with marketing support and local onboarding.',
      },
    ],
    steps: [
      'Submit a partnership application',
      'Complete the application review',
      'Receive your partner dashboard',
      'Start referring clients',
    ],
  },
  platforms: {
    label: 'Platforms',
    title: 'Powerful Technology',
    titleAccent: 'Every Device',
    description:
      'Chart, analyse, and execute from a unified workspace with institutional-grade stability and retail-friendly design.',
    facts: [
      { value: '99.9%', label: 'Uptime SLA' },
      { value: '<1ms', label: 'Avg. Routing' },
      { value: '80+', label: 'Indicators' },
      { value: '3', label: 'Device Types' },
    ],
  },
  resources: {
    label: 'Resources',
    title: 'Trading Tools &',
    titleAccent: 'Market Insights',
    description:
      'Calculators, session guides, and reference material to help you plan entries, size risk, and track macro events.',
    tools: [
      { title: 'Pip Value Calculator', description: 'Estimate per-pip profit or loss across any pair and lot size.' },
      { title: 'Margin Estimator', description: 'Preview required collateral before you open a leveraged position.' },
      { title: 'Session Clock', description: 'Track Asian, London, and New York overlaps in real time.' },
      { title: 'Economic Calendar', description: 'Monitor high-impact releases that move forex volatility.' },
      { title: 'Position Size Tool', description: 'Align lot size with your stop distance and risk percentage.' },
      { title: 'Swap Schedule', description: 'Review overnight financing on instruments you hold past close.' },
    ],
  },
  support: {
    label: 'Help Desk',
    title: 'We Are Here',
    titleAccent: 'When You Need Us',
    description:
      'Reach our client operations team for platform help, funding questions, or account verification.',
    faqs: [
      {
        q: 'How do I open a practice wallet?',
        a: 'Select Try Practice Account on any page and complete the short registration form. Simulation balances update with live market quotes.',
      },
      {
        q: 'What is the minimum live deposit?',
        a: 'Starter accounts activate from $100. Professional tiers begin at $2,500 depending on service level.',
      },
      {
        q: 'How fast are withdrawals processed?',
        a: 'Most requests are reviewed within one business day once identity verification is complete and no account checks remain outstanding.',
      },
      {
        q: 'Do you offer swap-free accounts?',
        a: 'Yes. The Shariah profile removes overnight swap on eligible instruments subject to product terms.',
      },
    ],
  },
  login: {
    label: 'Member Login',
    title: 'Sign In to',
    titleAccent: 'Your Portal',
    description: 'Access balances, statements, funding tools, and the Rise FX Desk from one secure login.',
  },
  register: {
    label: 'Create Account',
    title: 'Open Your',
    titleAccent: 'Rich Rise Profile',
    description: 'Choose a practice or live wallet and start trading global forex markets in minutes.',
  },
} as const

export const ctaButtons = {
  practice: 'Try Practice Account',
  live: 'Start Live Account',
  portal: 'Member Login',
  begin: 'Create Account',
} as const

export const heroContent = {
  badge: company.legalName,
  headlineLine1: 'Where Currency Markets',
  headlineAccent: 'Meet Serious Traders',
  description:
    'Tap into a vast universe of tradeable instruments on infrastructure built for rapid fills, accurate pricing, and adaptable workflows. Newcomers and veterans alike benefit from Rich Rise analytics, funding options, and human support when volatility strikes.',
  stats: [
    { value: '150+', label: 'FX Pairs Listed' },
    { value: '0.0', label: 'Pip Spreads From' },
    { value: '24/5', label: 'Session Coverage' },
  ],
  dashboardTitle: 'Session Watchlist',
  dashboardStatus: 'Feeds Online',
  ticker: [
    'EUR/USD · GBP/USD · USD/JPY · XAU/USD',
    'Interbank-Style Pricing on Majors',
    'Leverage Caps up to 1:500',
    'Halal Account Structures Available',
    'Account Shield Against Negative Equity',
    'Sub-Millisecond Routing Average',
  ],
  liveStats: [
    { pair: 'EUR/USD', price: '1.0872', change: '+0.18%', up: true },
    { pair: 'GBP/USD', price: '1.2634', change: '-0.08%', up: false },
    { pair: 'USD/JPY', price: '149.82', change: '+0.24%', up: true },
    { pair: 'XAU/USD', price: '2,358.40', change: '+0.31%', up: true },
  ],
  floatBadgeTop: 'EUR/USD +12 pips',
  floatBadgeBottom: 'Spread from 0.0',
} as const

export const marketsContent = {
  label: 'Experience',
  title: 'Sharpen Your',
  titleAccent: 'Market Edge',
  description:
    'Operate on modern routing, abundant counterparty depth, and an interface that scales from your first micro-lot to institutional-sized tickets — without switching platforms.',
  features: [
    {
      title: 'Thousands of Listings',
      description: 'Spread risk across an extensive catalogue spanning currencies, commodities, benchmarks, and digital assets — all linked to one login.',
    },
    {
      title: 'Any Holding Period',
      description: 'Run quick intraday plays or stretch positions across weeks. Order types and session windows adapt to how you actually trade.',
    },
    {
      title: 'Sizing on Your Terms',
      description: 'Open a live wallet from $100 or rehearse tactics on a complimentary simulation. Deposit size never dictates your right to participate.',
    },
    {
      title: 'Favourable Deal Terms',
      description: 'Benefit from transparent commissions, competitive raw pricing, balance safeguards, and overnight-fee waivers on qualifying instruments.',
    },
  ],
} as const

export const portfoliosContent = {
  label: 'Instruments',
  title: 'Six Routes Into',
  titleAccent: 'Global Liquidity',
  description:
    'Currency trading remains our foundation, yet you can rotate into complementary sectors — metals, equity benchmarks, single names, contracts, and crypto — whenever your thesis demands it.',
  assets: [
    {
      name: 'Forex',
      description: 'G10, cross-rate, and frontier currencies quoted with live, depth-backed pricing.',
      count: '150+',
      color: 'from-sky-500/15 to-sky-600/5',
      featured: true,
    },
    {
      name: 'Metals',
      description: 'Bullion and industrial metals for inflation hedges or momentum plays outside equity hours.',
      count: '12',
      color: 'from-amber-500/15 to-amber-600/5',
      featured: false,
    },
    {
      name: 'Indices',
      description: 'Synthetic baskets mirroring US technology leaders, European large caps, and Asia-Pacific benchmarks.',
      count: '30+',
      color: 'from-violet-500/15 to-violet-600/5',
      featured: false,
    },
    {
      name: 'Stocks',
      description: 'Express directional views on multinational listings via margined exposure — no share certificate required.',
      count: '800+',
      color: 'from-emerald-500/15 to-emerald-600/5',
      featured: false,
    },
    {
      name: 'Futures',
      description: 'Standardised contracts on energy complexes, soft commodities, and macro index underlyings.',
      count: '45+',
      color: 'from-orange-500/15 to-orange-600/5',
      featured: false,
    },
    {
      name: 'Crypto',
      description: 'High-velocity digital pairs with extended hours for weekend and overnight strategists.',
      count: '60+',
      color: 'from-cyan-500/15 to-cyan-600/5',
      featured: false,
    },
  ],
} as const

export const intelligenceContent = {
  label: 'Derivatives',
  title: 'Capture Moves',
  titleAccent: 'In Either Direction',
  description:
    'CFDs let you speculate on price changes without taking delivery of the underlying. Express bullish or bearish convictions on forex, bullion, indices, and more — amplified by leverage and backed by tight dealing spreads.',
  feedTitle: 'Live Sentiment Board',
  feedStatus: 'Updating',
  signals: [
    { label: 'Upside Pressure', value: 72, color: 'bg-emerald-500', accent: 'text-emerald-400' },
    { label: 'Volatility Gauge', value: 45, color: 'bg-amber-500', accent: 'text-amber-400' },
    { label: 'EUR Flow Strength', value: 68, color: 'bg-indigo-500', accent: 'text-indigo-400' },
    { label: 'Book Depth Rating', value: 91, color: 'bg-sky-500', accent: 'text-sky-400' },
  ],
  insights: [
    { time: '08:15 UTC', event: 'European cash open lifts EUR/USD past overnight consolidation — buyers in control', type: 'signal' as const },
    { time: '09:42 UTC', event: 'USD/JPY flirts with the 150.00 psychological barrier — breakout scenario active', type: 'alert' as const },
    { time: '13:30 UTC', event: 'Sterling whipsaw expected around New York data — widen risk buffers', type: 'insight' as const },
  ],
  ctaPrimary: ctaButtons.practice,
  ctaSecondary: ctaButtons.live,
} as const

export const riseEdgeContent = {
  label: 'Advantages',
  title: 'What Sets',
  titleAccent: 'Rich Rise Apart',
  description:
    'Frictionless order routing, dependable treasury flows, multi-layer liquidity, and people who answer the phone — the essentials professionals expect when capital is on the line.',
  pillars: [
    {
      tag: 'Halal Trading',
      title: 'Sharia-Aligned Portfolios',
      description: 'Select account structures that omit overnight financing on approved instruments, supporting faith-conscious trading styles.',
    },
    {
      tag: 'Rapid Treasury',
      title: 'Quick In, Quick Out',
      description: 'Fund and withdraw through streamlined payment rails so your balance reflects reality, not paperwork delays.',
    },
    {
      tag: 'Thick Books',
      title: 'Multi-Tier Liquidity',
      description: 'Aggregate pricing from diverse sources keeps fills tight even when headlines spark sudden volume surges.',
    },
    {
      tag: 'Global Desk',
      title: `Assistance in ${company.supportLanguages} Tongues`,
      description: 'Specialists monitor tickets day and night, resolving platform, funding, and account-verification questions in your language.',
    },
    {
      tag: 'Personal Adviser',
      title: 'One-on-One Market Guidance',
      description: 'Funded clients may pair with an assigned consultant to stress-test ideas, size positions, and plan around macro calendars.',
    },
  ],
} as const

export const riseTerminalContent = {
  label: 'Workspace',
  title: 'One Platform.',
  titleAccent: 'Every Screen.',
  description:
    'Stable dealing spreads, equity protection on margined accounts, and a charting environment tuned for discretionary and systematic forex operators alike.',
  terminalName: 'Rise FX Desk',
  chartPair: 'EUR/USD',
  chartTimeframe: 'M15 View',
  chartPrice: '1.0872 +0.18%',
  features: [
    {
      title: 'Instant Chart Orders',
      description: 'Fire instructions directly from the price pane — no tab switching when seconds determine slippage.',
    },
    {
      title: 'Saved Layout Presets',
      description: 'Store favourite panel arrangements, colour themes, and indicator stacks for one-tap recall.',
    },
    {
      title: 'Mobile, Tablet & PC',
      description: 'Carry open risk, alerts, and drawings between iOS, Android, and desktop without manual exports.',
    },
    {
      title: 'Preloaded Study Library',
      description: 'Momentum, volatility, and overlay tools — RSI, MACD, Bollinger, Fibonacci, and dozens more ship ready to apply.',
    },
  ],
} as const

export const ctaContent = {
  badge: 'Open your account today',
  title: 'Trade Global',
  titleAccent: 'Forex Markets',
  highlights: [
    { value: '150+', label: 'Currency Pairs' },
    { value: '0.0', label: 'Raw Spreads' },
    { value: '24/5', label: 'Trading Sessions' },
  ],
} as const

export const metaContent = {
  title: 'Rich Rise Global | Multi-Asset Trading Platform',
  description:
    'Rich Rise Global — access 150+ forex pairs, derivatives, and cross-asset instruments with competitive spreads, halal account options, and a professional trading workspace. Operated by RICHRISE GLOBAL LIMITED.',
} as const
