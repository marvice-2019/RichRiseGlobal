import { BrowserRouter, Routes, Route } from 'react-router-dom'
import MainLayout from './layouts/MainLayout'
import HomePage from './pages/HomePage'
import MarketsPage from './pages/MarketsPage'
import AccountsPage from './pages/AccountsPage'
import PartnersPage from './pages/PartnersPage'
import PlatformsPage from './pages/PlatformsPage'
import ResourcesPage from './pages/ResourcesPage'
import SupportPage from './pages/SupportPage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<MainLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/markets" element={<MarketsPage />} />
          <Route path="/accounts" element={<AccountsPage />} />
          <Route path="/partners" element={<PartnersPage />} />
          <Route path="/platforms" element={<PlatformsPage />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/support" element={<SupportPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
