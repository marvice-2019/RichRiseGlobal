import { motion } from 'framer-motion'
import PageHero from '../components/PageHero'
import AssetCategories from '../components/AssetCategories'
import CtaSection from '../components/CtaSection'
import { AnimatedSection, StaggerItem } from '../components/AnimatedSection'
import { pageContent } from '../data/siteContent'

export default function AccountsPage() {
  const { accounts } = pageContent

  return (
    <main>
      <PageHero
        label={accounts.label}
        title={accounts.title}
        titleAccent={accounts.titleAccent}
        description={accounts.description}
      />

      <AnimatedSection className="py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            {accounts.tiers.map((tier, i) => (
              <StaggerItem key={tier.name} index={i}>
                <motion.div
                  className={`h-full rounded-2xl border p-6 ${
                    'featured' in tier && tier.featured
                      ? 'border-brand-gold/40 bg-gradient-to-br from-brand-gold/10 to-brand-card ring-1 ring-brand-gold/20'
                      : 'border-brand-border bg-brand-card'
                  }`}
                  whileHover={{ y: -4 }}
                >
                  {'featured' in tier && tier.featured && (
                    <span className="text-[10px] font-bold uppercase tracking-wider text-brand-gold mb-3 block">
                      Most Popular
                    </span>
                  )}
                  <h3 className="text-xl font-bold mb-1">{tier.name}</h3>
                  <p className="text-brand-gold text-sm font-semibold mb-4">{tier.deposit}</p>
                  <p className="text-brand-muted text-sm mb-5 leading-relaxed">{tier.description}</p>
                  <ul className="space-y-2">
                    {tier.perks.map((perk) => (
                      <li key={perk} className="flex items-center gap-2 text-sm text-gray-300">
                        <span className="w-1.5 h-1.5 rounded-full bg-brand-gold shrink-0" />
                        {perk}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              </StaggerItem>
            ))}
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection className="py-16 lg:py-20 bg-brand-card/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-center mb-10">How to Get Started</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {accounts.steps.map((step, i) => (
              <div key={step.title} className="text-center p-5 rounded-xl border border-brand-border bg-brand-card/60">
                <span className="inline-flex w-10 h-10 rounded-full bg-brand-gold/15 text-brand-gold font-bold items-center justify-center mb-4">
                  {i + 1}
                </span>
                <h3 className="font-semibold mb-2">{step.title}</h3>
                <p className="text-brand-muted text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </AnimatedSection>

      <AssetCategories />
      <CtaSection />
    </main>
  )
}
