import { Link } from 'react-router-dom'
import PageHero from '../components/PageHero'
import { AnimatedSection } from '../components/AnimatedSection'
import { authLinks, ctaButtons, pageContent } from '../data/siteContent'

export default function LoginPage() {
  const { login } = pageContent

  return (
    <main>
      <PageHero label={login.label} title={login.title} titleAccent={login.titleAccent} description={login.description} />

      <AnimatedSection className="pb-24">
        <div className="max-w-md mx-auto px-4">
          <form className="rounded-2xl border border-brand-border bg-brand-card p-8 space-y-4">
            <div>
              <label className="block text-sm text-brand-muted mb-1.5">Email</label>
              <input
                type="email"
                placeholder="you@example.com"
                className="w-full px-4 py-3 rounded-xl bg-[#050b1d] border border-brand-border text-sm focus:border-brand-gold/50 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm text-brand-muted mb-1.5">Password</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl bg-[#050b1d] border border-brand-border text-sm focus:border-brand-gold/50 outline-none"
              />
            </div>
            <button type="button" className="btn-primary w-full py-3.5 rounded-xl text-sm">
              {ctaButtons.portal}
            </button>
            <p className="text-center text-sm text-brand-muted">
              No profile yet?{' '}
              <Link to={authLinks.register.path} className="text-brand-gold hover:underline">
                {authLinks.register.label}
              </Link>
            </p>
          </form>
        </div>
      </AnimatedSection>
    </main>
  )
}
