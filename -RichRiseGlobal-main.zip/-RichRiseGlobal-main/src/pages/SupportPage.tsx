import PageHero from '../components/PageHero'
import { AnimatedSection } from '../components/AnimatedSection'
import { company, contactContent, pageContent } from '../data/siteContent'

export default function SupportPage() {
  const { support } = pageContent

  return (
    <main>
      <PageHero
        label={support.label}
        title={support.title}
        titleAccent={support.titleAccent}
        description={support.description}
      />

      <AnimatedSection className="py-16 lg:py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-10 mb-16">
            <div className="rounded-2xl border border-brand-border bg-brand-card p-8">
              <h2 className="text-xl font-bold mb-6">Contact Details</h2>
              <div className="space-y-4 text-sm">
                <p>
                  <span className="text-brand-muted block mb-1">Email</span>
                  <a href={company.emailHref} className="text-brand-gold hover:underline">{company.email}</a>
                </p>
                <p>
                  <span className="text-brand-muted block mb-1">Phone</span>
                  <a href={company.phoneHref} className="text-brand-gold hover:underline">{company.phone}</a>
                </p>
                <p>
                  <span className="text-brand-muted block mb-1">Hours</span>
                  <span className="text-gray-300">{contactContent.hours}</span>
                </p>
                <p>
                  <span className="text-brand-muted block mb-1">Registered Office</span>
                  <span className="text-gray-300">{company.registeredOffice}</span>
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-bold mb-2">Common Questions</h2>
              {support.faqs.map((faq) => (
                <details
                  key={faq.q}
                  className="group rounded-xl border border-brand-border bg-brand-card/60 p-5 open:border-brand-gold/30"
                >
                  <summary className="font-medium cursor-pointer list-none flex justify-between items-center">
                    {faq.q}
                    <span className="text-brand-gold group-open:rotate-45 transition-transform">+</span>
                  </summary>
                  <p className="text-brand-muted text-sm mt-3 leading-relaxed">{faq.a}</p>
                </details>
              ))}
            </div>
          </div>
        </div>
      </AnimatedSection>
    </main>
  )
}
