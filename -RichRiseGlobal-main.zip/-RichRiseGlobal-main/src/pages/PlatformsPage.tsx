import PageHero from '../components/PageHero'
import PlatformSection from '../components/PlatformSection'
import CtaSection from '../components/CtaSection'
import AnimatedCounter from '../components/AnimatedCounter'
import { AnimatedSection, StaggerItem } from '../components/AnimatedSection'
import { pageContent } from '../data/siteContent'

export default function PlatformsPage() {
  const { platforms } = pageContent

  return (
    <main>
      <PageHero
        label={platforms.label}
        title={platforms.title}
        titleAccent={platforms.titleAccent}
        description={platforms.description}
      />

      <AnimatedSection className="py-12 lg:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {platforms.facts.map((fact, i) => (
              <StaggerItem key={fact.label} index={i}>
                <div className="text-center p-5 rounded-xl border border-brand-border bg-brand-card/50">
                  <div className="text-2xl font-bold gradient-text mb-1">
                    <AnimatedCounter value={fact.value} />
                  </div>
                  <div className="text-xs text-brand-muted uppercase tracking-wider">{fact.label}</div>
                </div>
              </StaggerItem>
            ))}
          </div>
        </div>
      </AnimatedSection>

      <PlatformSection />
      <CtaSection />
    </main>
  )
}
