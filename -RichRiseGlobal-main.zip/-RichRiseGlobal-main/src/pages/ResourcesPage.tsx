import PageHero from '../components/PageHero'
import { AnimatedSection, StaggerItem } from '../components/AnimatedSection'
import { pageContent } from '../data/siteContent'

export default function ResourcesPage() {
  const { resources } = pageContent

  return (
    <main>
      <PageHero
        label={resources.label}
        title={resources.title}
        titleAccent={resources.titleAccent}
        description={resources.description}
      />

      <AnimatedSection className="py-16 lg:py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {resources.tools.map((tool, i) => (
              <StaggerItem key={tool.title} index={i}>
                <div className="h-full p-6 rounded-2xl border border-brand-border bg-brand-card hover:border-brand-gold/30 transition-colors group cursor-pointer">
                  <div className="w-10 h-10 rounded-lg bg-brand-gold/10 text-brand-gold flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <h3 className="font-semibold mb-2">{tool.title}</h3>
                  <p className="text-brand-muted text-sm leading-relaxed">{tool.description}</p>
                </div>
              </StaggerItem>
            ))}
          </div>
        </div>
      </AnimatedSection>
    </main>
  )
}
