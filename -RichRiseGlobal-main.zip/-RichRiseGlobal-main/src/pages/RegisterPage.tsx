import { Link } from 'react-router-dom'
import PageHero from '../components/PageHero'
import { AnimatedSection } from '../components/AnimatedSection'
import { authLinks, ctaButtons, pageContent } from '../data/siteContent'

export default function RegisterPage() {
  const { register } = pageContent

  return (
    <main>
      <PageHero
        label={register.label}
        title={register.title}
        titleAccent={register.titleAccent}
        description={register.description}
      />

      <AnimatedSection className="pb-24">
        <div className="max-w-md mx-auto px-4">
          <form className="rounded-2xl border border-brand-border bg-brand-card p-8 space-y-4">
            <div>
              <label className="block text-sm text-brand-muted mb-1.5">Full Name</label>
              <input
                type="text"
                placeholder="Your name"
                className="w-full px-4 py-3 rounded-xl bg-[#050b1d] border border-brand-border text-sm focus:border-brand-gold/50 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm text-brand-muted mb-1.5">Email</label>
              <input
                type="email"
                placeholder="you@example.com"
                className="w-full px-4 py-3 rounded-xl bg-[#050b1d] border border-brand-border text-sm focus:border-brand-gold/50 outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button type="button" className="btn-outline py-3 rounded-xl text-sm">
                {ctaButtons.practice}
              </button>
              <button type="button" className="btn-primary py-3 rounded-xl text-sm">
                {ctaButtons.live}
              </button>
            </div>
            <p className="text-center text-sm text-brand-muted">
              Already registered?{' '}
              <Link to={authLinks.login.path} className="text-brand-gold hover:underline">
                {authLinks.login.label}
              </Link>
            </p>
          </form>
        </div>
      </AnimatedSection>
    </main>
  )
}
