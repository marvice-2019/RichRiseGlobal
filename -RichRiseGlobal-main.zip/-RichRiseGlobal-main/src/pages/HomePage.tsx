import Hero from '../components/Hero'
import TradingExperience from '../components/TradingExperience'
import AssetCategories from '../components/AssetCategories'
import MarketIntelligence from '../components/MarketIntelligence'
import WhyChoose from '../components/WhyChoose'
import PlatformSection from '../components/PlatformSection'
import CtaSection from '../components/CtaSection'

export default function HomePage() {
  return (
    <main>
      <Hero />
      <div className="section-divider max-w-7xl mx-auto" />
      <TradingExperience />
      <AssetCategories />
      <div className="section-divider max-w-7xl mx-auto" />
      <MarketIntelligence />
      <WhyChoose />
      <PlatformSection />
      <CtaSection />
    </main>
  )
}
