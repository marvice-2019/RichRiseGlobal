import PageHero from '../components/PageHero'
import CtaSection from '../components/CtaSection'
import AnimatedCounter from '../components/AnimatedCounter'
import { AnimatedSection, StaggerItem } from '../components/AnimatedSection'
import { pageContent } from '../data/siteContent'

export default function PartnersPage() {
  const { partners } = pageContent

  return (
    <main>
      <PageHero
        label={partners.label}
        title={partners.title}
        titleAccent={partners.titleAccent}
        description={partners.description}
      />

      <AnimatedSection className="py-16 lg:py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-3 gap-8 text-center mb-16">
            {partners.stats.map((stat, i) => (
              <StaggerItem key={stat.label} index={i}>
                <div className="text-3xl font-bold gradient-text mb-2">
                  <AnimatedCounter value={stat.value} />
                </div>
                <div className="text-sm text-brand-muted uppercase tracking-wider">{stat.label}</div>
              </StaggerItem>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-16">
            {partners.programs.map((program, i) => (
              <StaggerItem key={program.title} index={i}>
                <div className="h-full p-6 rounded-2xl border border-brand-border bg-brand-card hover:border-brand-gold/30 transition-colors">
                  <h3 className="text-lg font-semibold mb-3">{program.title}</h3>
                  <p className="text-brand-muted text-sm leading-relaxed">{program.description}</p>
                </div>
              </StaggerItem>
            ))}
          </div>

          <div className="rounded-2xl border border-brand-border bg-brand-card/60 p-8">
            <h2 className="text-xl font-bold text-center mb-8">Partnership Onboarding</h2>
            <ol className="grid sm:grid-cols-2 gap-4">
              {partners.steps.map((step, i) => (
                <li key={step} className="flex items-start gap-3 text-sm text-gray-300">
                  <span className="w-7 h-7 rounded-lg bg-brand-gold/15 text-brand-gold font-bold flex items-center justify-center shrink-0 text-xs">
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </AnimatedSection>

      <CtaSection />
    </main>
  )
}
