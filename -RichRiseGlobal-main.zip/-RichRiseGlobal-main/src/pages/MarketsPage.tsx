import PageHero from '../components/PageHero'
import TradingExperience from '../components/TradingExperience'
import MarketIntelligence from '../components/MarketIntelligence'
import CtaSection from '../components/CtaSection'
import { pageContent } from '../data/siteContent'

export default function MarketsPage() {
  const { markets } = pageContent
  return (
    <main>
      <PageHero
        label={markets.label}
        title={markets.title}
        titleAccent={markets.titleAccent}
        description={markets.description}
      />
      <TradingExperience />
      <MarketIntelligence />
      <CtaSection />
    </main>
  )
}
