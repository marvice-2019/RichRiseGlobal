import { Outlet } from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'
import FloatingBackground from '../components/FloatingBackground'

export default function MainLayout() {
  return (
    <>
      <FloatingBackground />
      <div className="relative z-10">
        <Header />
        <Outlet />
        <Footer />
      </div>
    </>
  )
}
